package java111.unit5.project;
import java.util.*;
/**
 *  This class controls the application for processing all orders.
 *
 *  @author Simone LaMarche
 */
public class ProcessOrders {

    private ArrayList<ProcessItem> orderList = new ArrayList<ProcessItem>();

    /**
     *  This method contains calls for running the application.
     */
    public void run() {
        addOrder();
        display();
    }

    /**
     *  This method instantiates several objects and adds them to order list.
     */
    public void addOrder() {
        ProcessItem order1 = new ProcessItem("Steven", 120, "pebbles", 8, .25);
        orderList.add(order1);

        ProcessHandling order2 = new ProcessHandling("Simone", 130, "marbles", 2, 3.50, 10.5);
        orderList.add(order2);

        ProcessHandling order3 = new ProcessHandling("Sam", 140, "boulders", 3, 19.99, 75);
        orderList.add(order3);
    }

    /**
     * This method loops through the order list and displays
     * the report of each order.
     */
     public void display() {
        for(ProcessItem order : orderList) {
            String printed = order.toString();
            System.out.println(printed);
        }

     }

}

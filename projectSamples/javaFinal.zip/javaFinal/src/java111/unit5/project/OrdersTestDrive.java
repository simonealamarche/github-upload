package java111.unit5.project;
/**
 *  This is the main class for project 5 - processing orders.
 *
 *  @author Simone LaMarche
 */
public class OrdersTestDrive {
    /**
     * This is the main method for project 5 - processing orders.
     */
    public static void main(String[] args) {

        ProcessOrders test = new ProcessOrders();
        test.run();

    }
}

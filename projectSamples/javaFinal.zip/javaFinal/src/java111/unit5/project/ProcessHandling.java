package java111.unit5.project;
/**
 *  This class handles order processing for a single item including
 *  handling surcharge
 *  @author Simone LaMarche
 */
public class ProcessHandling extends ProcessItem {

    private String customerName;
    private int customerNumber;
    private String productName;
    private int quantityOrdered;
    private double unitPrice;
    private double itemWeight;
    private double handlingCharge;

    /**
     * Constructor for the class includes a call to the super class
     * @param customerName the customer's name
     * @param customerNumber the customer's number
     * @param productName the product name
     * @param quantityOrdered the product quantity ordered
     * @param unitPrice the product unit price
     * @param itemWeight the product item weight
     */
    public ProcessHandling(String customerName, int customerNumber
            , String productName, int quantityOrdered, double unitPrice
            , double itemWeight) {
        super(customerName, customerNumber, productName, quantityOrdered, unitPrice);

        this.itemWeight = itemWeight;
    }

    /**
     * This method will first call on the superclass method to perform
     * the item sub total and then add the handling charge calculation.
     *
     * @return grand total
     */
    public double calculatePrice() {

        double subTotal = super.calculatePrice();

        //calculate handling charge
        if (itemWeight < 25) {
            handlingCharge = 4;
        } else if (itemWeight >= 25 && itemWeight < 45) {
            handlingCharge = 5;
        } else if (itemWeight >= 45 && itemWeight < 75) {
            handlingCharge = 6;
        } else if (itemWeight >= 75) {
            handlingCharge = 7;
        } else {
            handlingCharge = 0;
        }
        //calculate grand total
        double grandTotal = (subTotal + handlingCharge);
        return grandTotal;
    }

    /**
     * This method will assemble the order report by calling on the superclass
     * and appending information for handling.
     *
     * @return item Summary
     */
    public String toString() {
        String itemSummaryPt1 = super.toString();

        String itemSummary = itemSummaryPt1
                + "\nPlus a $" + handlingCharge + " handling charge"
                + "\nGrand Total: $" + calculatePrice();

        return itemSummary;
    }

}

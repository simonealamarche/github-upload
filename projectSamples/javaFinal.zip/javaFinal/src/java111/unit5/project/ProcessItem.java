package java111.unit5.project;

/**
 *  This class handles order processing for a single item.
 *  @author Simone LaMarche
 */
public class ProcessItem {

    private String customerName;
    private int customerNumber;
    private String productName;
    private int quantityOrdered;
    private double unitPrice;

    private double itemTotal;

    /**
     * Constructor for the class
     * @param customerName the customer's name
     * @param customerNumber the customer's number
     * @param productName the product name
     * @param quantityOrdered the product quantity ordered
     * @param unitPrice the product unit price  
     */
    public ProcessItem(String customerName, int customerNumber
            , String productName, int quantityOrdered, double unitPrice) {
        this.customerName = customerName;
        this.customerNumber = customerNumber;
        this.productName = productName;
        this.quantityOrdered = quantityOrdered;
        this.unitPrice = unitPrice;
    }

    /**
     * This method calculates the basic item total
     *
     * @return itemTotal: quantity x price
     */
    public double calculatePrice() {
        itemTotal = quantityOrdered * unitPrice;
        return itemTotal;
    }

    /**
     * This method creates a string for the order summary.
     *
     * @return itemSummary - summary of the ordered item
     */
    public String toString() {
        calculatePrice();
        String itemSummary = "\nCustomer: " + customerName
                + "\nItem Ordered: " + productName
                + "\nUnit Price: $" + unitPrice
                + "\nQuantity Ordered: " + quantityOrdered
                + "\nTotal: $" + itemTotal;

        return itemSummary;
    }
}

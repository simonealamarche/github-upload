<?php
class UserList
{

    public $my_list = array();

    //this function returns an associative array of user list items (id and name)
    public function create_assoc_list($user_id)
    {
        $this->user_id = $user_id;

        //connect and query database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        //get ingredient list
        $query = "SELECT id, ingredient
                  FROM user_list
                  WHERE user_id = '$this->user_id'";
        $data = mysqli_query($dbc, $query)
            or die('error querying database');

            $my_list_names = array();
            $my_list_ids = array();

            while($row = mysqli_fetch_array($data))
            {
                array_push($my_list_names, $row['ingredient']);
                array_push($my_list_ids, $row['id']);
            }
        $this->my_list = array_combine($my_list_ids, $my_list_names);
        return $this->my_list;

    }

    //this function removes an item from a list id
    public function remove_list_item($list_id)
    {
        $this->item_id = $list_id;

        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        //query to remove item from user_list
        $query = "DELETE FROM user_list
                  WHERE id = '$this->item_id'";

        $data = mysqli_query($dbc, $query)
            or die ('error querying database');

    }
}

?>

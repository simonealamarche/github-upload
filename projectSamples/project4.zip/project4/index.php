<?php
    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    //database connection
    require_once('connectvars.php');
    //recipe class
    require_once('recipe.php');

    //intro
?>
    <div class="page-intro">
        <h1>Every night is taco night</h1>
        <p>browse recipes and add ingredients to your personalized shopping list.</p>
    </div>

<?php

    //get recipe ids
    $r = new Recipe;
    $r->get_recipe_ids();

    //prints all recipe cards
    $r->print_all_recipes();

    //Footer
    require_once('footer.php');

?>

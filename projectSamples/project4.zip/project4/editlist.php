<?php
    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    //database connection
    require_once('connectvars.php');

    //make sure that user is logged in
    if (!isset($_SESSION['user_id']))
    {
        echo '<p>Please <a href="login.php">log in</a>'
                . ' or <a href="signup.php">create an account</a>'
                . 'to create your taco night shopping list.</p>';
        exit();
    }
    else
    {
        $user_id = $_SESSION['user_id'];
        $todays_date = date('Y-m-d');
    }

    //check to see if enterItem is set
    if(isset($_POST['enterItem']))
    {
        //connetct to databse
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        //get item
        $new_item = mysqli_real_escape_string($dbc, trim($_POST['enterItem']));

        //check variable has data and add new item to user list
        if(!empty($new_item)) {

            //query new item
            $query_ni = "INSERT INTO user_list (user_id, date_created, ingredient)
                         VALUES ('$user_id', '$todays_date', '$new_item')";
            $data_ni = mysqli_query($dbc, $query_ni)
                or die('error querying database');

        }// end of new item not empty
        else
        {
            //re-direct to user page
            header("Location: viewprofile.php");
        }
    } //end of enter item is set
    else
    {
        echo '<p class="alert alert-danger" role="alert"> '
                . 'Sorry, an error has occured</p>';
        exit();
    }

    mysqli_close($dbc);
    //re-direct to user page
    header("Location: viewprofile.php");


 ?>

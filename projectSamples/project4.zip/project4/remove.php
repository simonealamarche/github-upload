<?php
    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    //database connection
    require_once('connectvars.php');

    //user list class
    require_once('userlist.php');

    //make sure that user is logged in
    if (!isset($_SESSION['user_id']))
    {
        echo '<p>Please <a href="login.php">log in</a>'
                . ' or <a href="signup.php">create an account</a>'
                . 'to create your taco night shopping list.</p>';
        exit();
    }
    else
    {
        $user_id = $_SESSION['user_id'];

    }


    // Somewhere before evaluating $my_list unserialize it back into an array list from the SESSION var
    $my_list = unserialize($_SESSION['list']);


    foreach($my_list as $list_id => $list_value)
    {

        //calls functions to remove item
        if(isset($_POST[$list_id]))
        {
            $ul = new UserList;
            $ul->remove_list_item($list_id);
        }
        //re-direct to user profile
        header("Location: viewprofile.php");

    }


 ?>

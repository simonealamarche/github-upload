
<?php
    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    // database connection
    require_once('connectvars.php');
    //recipe class
    require_once('recipe.php');

    //check that user is logged in as admin

    if(isset($_SESSION['user_id']) && ($_SESSION['is_admin']) == 1) {

        // Connect to the database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        //control for submitting new recipe
        if(isset($_POST['submitRecipe']))
        {
            //get form data
            $recipe_title = mysqli_real_escape_string($dbc, trim($_POST['recipeTitle']));
            $recipe_instruction = mysqli_real_escape_string($dbc, trim($_POST['recipeInstruction']));

            $new_picture = mysqli_real_escape_string($dbc, trim($_FILES['new_picture']['name']));
            $new_picture_type = $_FILES['new_picture']['type'];
            $new_picture_size = $_FILES['new_picture']['size'];
            $error = false;

            //validate new_picture and move to folder
            if(!empty($new_picture))
            {
                if ((($new_picture_type == 'image/gif')
                    || ($new_picture_type == 'image/jpeg')
                    || ($new_picture_type == 'image/pjpeg')
                    || ($new_picture_type == 'image/png'))
                    && ($new_picture_size > 0))
                {
                        if ($_FILES['new_picture']['error'] == 0)
                        {
                            //list($new_picture_width, $new_picture_height) = getimagesize($_FILES['new_picture']['tmp_name']);
                            // Move the file to the target upload folder
                            $target = 'images/' . basename($new_picture);
                            move_uploaded_file($_FILES['new_picture']['tmp_name'], $target);
                        }
                }
                else
                {
                    // The new picture file is not valid, so delete the temporary file and set the error flag
                    @unlink($_FILES['new_picture']['tmp_name']);
                    $error = true;
                }

            } //end of new_picture not empty

            $r = new Recipe;
            $r->add_new_recipe($recipe_title, $recipe_instruction, $new_picture);
        }

        //control for submitting new ingredient
        if(isset($_POST['submitIngredient']))
        {
            //get form data
            $new_ingredient = $_POST['newIngredeint'];

            //insert ingredient into database
            $i = new Recipe;
            $i->add_new_ingredient($new_ingredient);
        }

        //control for submitting new recipe ingredient
        if(isset($_POST['submitRecipeIngredient']))
        {
            //get form data
            $recipe = $_POST['recipe'];
            $ingredient = $_POST['ingredient'];
            $ingredient_description = $_POST['ingredientDescription'];

            //insert recipe ingredient into database
            $ri = new Recipe;
            $ri->add_new_recipe_ingredient($recipe, $ingredient, $ingredient_description);

        }

?>
        <!-- New recipe form -->
        <div id="admin-page">
        <h2>Add a new recipe</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"
              enctype="multipart/form-data">
            <div class="form-group">
            <label for="recipeTitle">Recipe Title: </label>
            <input type="text" id="recipeTitle" name="recipeTitle">
            </div>

            <div class="form-group">
            <label for="recipeInstruction">Instructions: </label>
            <textarea id="recipeInstruction" name="recipeInstruction">
            </textarea>
            </div>

            <div class="form-group">
            <label for="new_picture">Upoload a new_picture:</label>
            <input type="file" id="new_picture" name="new_picture" />
            </div>

            <input class="btn btn-primary" type="submit" name="submitRecipe" value="submit new recipe">
        </form><br/><br/>

        <!-- New ingredient form -->
        <h2>Add a new ingrdient item</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="text" id="newIngredeint" name="newIngredeint"><br/><br/>
            <input class="btn btn-primary" type="submit" name="submitIngredient"
                   value="submit new item">
        </form><br/><br/>

        <!-- Recipe Ingredient from -->
        <h2>Add a new recipe ingredient</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

<?php
        $a = new Recipe();
        $recipe_ids = $a->get_recipe_ids();
        $ingredient_ids = $a->get_ingredient_ids();

        //select a recipe
        echo '<label for="recipe">Select a recipe: </label>';
        echo '<select id="recipe" name="recipe"><br/>';
        foreach($recipe_ids as $recipe_id)
        {
            //look up recipe title by id
            $recipe_title = $a->look_up_recipe_title($recipe_id);

            echo '<option value="' . $recipe_id . '">' . $recipe_title
                    . '</option>';
        }
        echo '</select><br/>';

        //select an ingredient
        echo '<label for="ingredient">Select an associated list item: </label>';
        echo '<select id="ingredient" name="ingredient"><br/>';
        foreach($ingredient_ids as $ingredient_id)
        {
            //look up ingredient name by id
            $ingredient_name = $a->look_up_ingredient_name($ingredient_id);

            echo '<option value="' . $ingredient_id . '">' . $ingredient_name
                    . '</option>';
        }
        echo '</select><br/>';

 ?>
        <label>Enter ingredient description</label>
        <textarea id="ingredientDescription" name="ingredientDescription">
        </textarea><br/><br/>
        <input class="btn btn-primary" type="submit" name="submitRecipeIngredient"
               value="submit recipe ingredient">
    </form>
    </div>

<?php

    } //end of is admin
    else
    {
        echo '<p>You must be logged in as an admin to access this page</p>';
    }

    require_once('footer.php');
?>

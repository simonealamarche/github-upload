</main>
<footer class="mastfoot mt-auto">
    <div class="inner">
        <p>Simone LaMarche, April 2020
        <a class="nav-link" href="admin.php">Admin Login</a></p>
    </div>
</footer>

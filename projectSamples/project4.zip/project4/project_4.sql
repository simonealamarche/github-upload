-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: project_4
-- ------------------------------------------------------
-- Server version	5.7.29-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ingredient`
--

DROP TABLE IF EXISTS `ingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingredient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ingredient_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredient`
--

LOCK TABLES `ingredient` WRITE;
/*!40000 ALTER TABLE `ingredient` DISABLE KEYS */;
INSERT INTO `ingredient` VALUES (1,'avacado'),(2,'bacon'),(3,'black pepper'),(4,'cherry tomatoes'),(5,'cilantro'),(6,'corn tortilla'),(7,'cotija'),(8,'eggs'),(9,'extra-virgin olive oil'),(10,'flour tortilla'),(11,'garlic'),(12,'green cabbage'),(13,'hot sauce'),(14,'jalapeno'),(15,'kosher salt'),(16,'lime'),(17,'monteray jack'),(18,'onion'),(19,'pineapple'),(20,'radishes'),(21,'red onion'),(22,'russet potato'),(23,'scallions'),(24,'shrimp'),(25,'skirt steak'),(26,'sriracha'),(27,'sugar'),(28,'unsalted butter'),(29,'vegetable oil'),(30,'white fish'),(31,'chips'),(32,'shredded cheese');
/*!40000 ALTER TABLE `ingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipe`
--

DROP TABLE IF EXISTS `recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` varchar(10000) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe`
--

LOCK TABLES `recipe` WRITE;
/*!40000 ALTER TABLE `recipe` DISABLE KEYS */;
INSERT INTO `recipe` VALUES (1,'Steak Tacos with Cilantro-Radish Salsa','<p>Heat 1 Tbsp. oil in a large skillet over high heat. Season steak\r\n        with salt and pepper and cook about 5 minutes per side for medium-rare.\r\n        Let steak rest 5 minutes.</p>\r\n        <p>Meanwhile, chop half of cilantro and toss with radishes, onions,\r\n        chile, lime juice, and remaining 1 Tbsp. oil in a medium bowl. Season\r\n        radish salsa with salt and pepper.</p>\r\n        <p>Slice steak and serve on tortillas topped with radish salsa, queso\r\n        fresco, and remaining cilantro.</p>','steak-taco.jpg'),(2,'Potato-Bacon Breakfast Tacos with Monterey Jack','<p>Cook bacon, stirring occasionally, until crisp, 6&ndash;8 minutes.\r\n        Using a slotted spoon, transfer to paper towels to drain (do not pour\r\n        off fat from skillet).</p>\r\n        <p>Add potatoes to skillet and cook, stirring often, until golden brown\r\n        and tender, 10&ndash;12 minutes. Using a slotted spoon, transfer to a\r\n        plate; season with salt and pepper.</p>\r\n        <p>Meanwhile, whisk eggs in a large bowl to blend; season with salt and\r\n        pepper. Heat butter in a large nonstick skillet over medium heat. Cook\r\n        eggs, stirring occasionally and scraping bottom of skillet with a\r\n        heatproof spatula to form large curds, until just set, about 3 minutes.\r\n        Remove from heat and mix in bacon.</p>\r\n        <p>Fill tortillas with egg mixture and potatoes and top with cheese,\r\n        avocado, and hot sauce.</p>','breakfast-taco.jpg'),(3,'Shrimp Tacos with Pineapple','<p>Place a rack in the highest position in oven; heat broiler. Toss\r\n        red onion, lime juice, sugar, and a pinch of salt in a small bowl; set\r\n        aside.</p>\r\n        <p>Toss pineapple and 1 Tbsp. oil on a rimmed baking sheet and arrange\r\n        in a single layer on half of baking sheet; reserve bowl. Broil\r\n        pineapple until lightly charred around the edges, 5-8 minutes.</p>\r\n        <p>Meanwhile, toss shrimp, Sriracha, and remaining 1 Tbsp. oil in\r\n        reserved bowl until shrimp are evenly coated; season with salt and\r\n        pepper and toss again.</p>\r\n        <p>Remove baking sheet from broiler and use a spatula to turn\r\n        pineapple pieces over. Arrange shrimp in a single layer on empty\r\n        half of baking sheet. Broil until shrimp are cooked through on top,\r\n        about 2 minutes. If your shrimp are opaque and springy to the touch,\r\n        they\'re done. Remove from broiler and turn shrimp (leave pineapple\r\n        alone). Broil again until shrimp are cooked through, 1-2 minutes.\r\n        Transfer shrimp and pineapple to a large bowl and season with more\r\n        salt and pepper.</p>\r\n        <p>Drain soaking liquid from onion into bowl with shrimp and pineapple;\r\n         set onion aside and toss shrimp and pineapple in pickling liquid.</p>\r\n        <p>Serve shrimp mixture with tortillas, avocado, jalapeno, cilantro,\r\n         lime wedges, and reserved pickled onion for making tacos.</p>','shrimp-taco.jpg'),(4,'Nachos','<p>melt cheese on chips</p>','Nachos.jpg');
/*!40000 ALTER TABLE `recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipe_ingredient`
--

DROP TABLE IF EXISTS `recipe_ingredient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipe_ingredient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipe_id` int(11) DEFAULT NULL,
  `ingredient_id` int(11) DEFAULT NULL,
  `ingredient_description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_recipe` (`recipe_id`),
  KEY `fk_ingredient` (`ingredient_id`),
  CONSTRAINT `fk_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredient` (`id`),
  CONSTRAINT `fk_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipe` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipe_ingredient`
--

LOCK TABLES `recipe_ingredient` WRITE;
/*!40000 ALTER TABLE `recipe_ingredient` DISABLE KEYS */;
INSERT INTO `recipe_ingredient` VALUES (1,3,21,'1/2 small red onion, thinly sliced'),(2,3,16,'2 tablespoons fresh lime juice'),(3,3,27,'Pinch of sugar'),(4,3,15,'Kosher salt'),(5,3,19,'1/4 medium pineapple, peeled, cored, cut lengthwise into spears, then crosswise 1/2 inch thick (about 2 cups)'),(6,3,9,'2 tablespoons extra-virgin olive oil, divided'),(7,3,24,'1 1/4 pounds shrimp, peeled, deveined'),(8,3,26,'1 tablespoon Sriracha'),(9,3,3,'Freshly ground black pepper'),(10,3,6,'8 corn tortillas, warmed'),(11,3,1,'1 avocado, sliced'),(12,3,14,'1 jalapeno, very thinly sliced, seeds removed if desired'),(13,3,5,'1/2 cup cilantro leaves with tender stems'),(14,3,16,'Lime wedges (for serving)'),(15,2,2,'4 ounces bacon (about 6 slices), cut into 1/2\" pieces'),(16,2,22,'1 large russet potato, peeled, cut into 1/4\" pieces'),(17,2,15,'Kosher salt, freshly ground pepper'),(18,2,10,'8 6\" flour tortillas, warmed'),(19,2,8,'8 large eggs'),(20,2,28,'2 tablespoons unsalted butter'),(21,2,17,'Monterey Jack or cheddar, shredded (for serving)'),(22,2,1,'1 avocado, sliced (for serving)'),(23,2,13,'Hot sauce (for serving)'),(24,2,29,'2 tablespoons vegetable oil, divided'),(25,1,25,'1 pound skirt or flank steak'),(26,1,15,'Kosher salt and freshly ground black pepper'),(27,1,5,'1/2 cup fresh cilantro leaves with tender stems, divided'),(28,1,20,'4 radishes, trimmed, chopped'),(29,1,23,'2 spring onions or 4 scallions, white and pale-green parts only, thinly sliced'),(30,1,14,'1/2 serrano chile or jalapeno, seeds removed if desired, finely chopped'),(31,1,16,'2 tablespoons fresh lime juice'),(32,1,6,'8 corn tortillas, warmed'),(33,1,7,'2 oz. queso fresco or Cotija cheese, crumbled'),(34,4,31,'        half a bag of chips'),(35,4,32,'        a lot of cheese');
/*!40000 ALTER TABLE `recipe_ingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2y$10$lOzqwP3bVXYT3le9LUnuneZuSLSkHo/R3XYD8qNO0E0mQ8VtFfvzW',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_list`
--

DROP TABLE IF EXISTS `user_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ingredient` varchar(200) DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user` (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_list`
--

LOCK TABLES `user_list` WRITE;
/*!40000 ALTER TABLE `user_list` DISABLE KEYS */;
INSERT INTO `user_list` VALUES (3,1,'ice cream','2020-05-02');
/*!40000 ALTER TABLE `user_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-02 18:01:37

<?php
    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    //database connection
    require_once('connectvars.php');

    //make sure that user is logged in
    if (!isset($_SESSION['user_id']))
    {
        echo '<p class="alert alert-warning" role="alert"> '
                . 'Please <a href="login.php">log in</a>'
                . ' or <a href="signup.php">create an account</a>'
                . ' to begin building your list.</p>';
        exit();
    }
    else
    {
        $todays_date = date('Y-m-d');
        $user_id = $_SESSION['user_id'];

    }

    //check to see if recipe id is set
    if(isset($_POST['recipeId']))
    {
        //get recipe id from post
        $my_recipe_id = $_POST['recipeId'];
        //TEST
        //echo $my_recipe_id;

        //get ingredient list from databse and place into an array.
        $ingredient_list = array();

        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        //query ingredient list

        $query_il = "SELECT i.ingredient_name
                     FROM ingredient AS i
                     JOIN recipe_ingredient AS ri
                     ON i.id = ri.ingredient_id
                     WHERE ri.recipe_id = '$my_recipe_id'";


        $data_il = mysqli_query($dbc, $query_il)
            or die('error querying databse');

        while($row = mysqli_fetch_array($data_il))
        {
            array_push($ingredient_list, $row['ingredient_name']);
        }

        //add ingredients to user list
        foreach($ingredient_list as $list_item)
        {
            //query user list
            $query_ul = "INSERT INTO user_list (user_id, ingredient, date_created)
                         VALUES ('$user_id', '$list_item', '$todays_date')";
            $data_ul = mysqli_query($dbc, $query_ul)
                or die('error querying database');

        }
    } //end of recipe id is set
    else
    {
        echo '<p class="alert alert-danger" role="alert"> '
                . 'Sorry, an error has occured</p>';
        exit();
    }

    mysqli_close($dbc);

    //re-direct to user page
    header("Location: viewprofile.php");







?>

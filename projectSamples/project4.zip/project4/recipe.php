<?php
class Recipe {

    public $recipe_ids = array();
    public $recipe_title;

    public $ingredient_ids = array();
    public $ingredient_name;

    public $new_recipe_title;
    public $recipe_instruction;

    public $new_ingredient_name;

    public $ri_recipe_id;
    public $ri_ingredient_id;
    public $new_ingredient_description;

    //public $recipe_titles = array();
    //public $recipe_instructions = array();

    //this function returns an array of all recipe ids
    public function get_recipe_ids()
    {
        // Connect to the database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        $query = "SELECT id FROM recipe";
        $data = mysqli_query($dbc, $query)
            or die('error getting ids');
        while($row = mysqli_fetch_array($data))
        {
            array_push($this->recipe_ids, $row['id']);
        }
        mysqli_close($dbc);
        return $this->recipe_ids;
    }

    //this function returns an array of all ingredient ids
    public function get_ingredient_ids()
    {
        // Connect to the database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        $query = "SELECT id
                  FROM ingredient
                  ORDER BY ingredient_name";
        $data = mysqli_query($dbc, $query)
            or die('error getting ids');
        while($row = mysqli_fetch_array($data))
        {
            array_push($this->ingredient_ids, $row['id']);
        }
        mysqli_close($dbc);
        return $this->ingredient_ids;
    }

    //this function returns a single recipe title
    public function look_up_recipe_title($recipe_id)
    {
        $this->recipe_id = $recipe_id;

        // Connect to the database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        $query = "SELECT title
                  FROM recipe
                  WHERE id = '$this->recipe_id'";
        $data = mysqli_query($dbc, $query)
            or die('error getting recipe title');
        $result = mysqli_fetch_array($data);
        $this->recipe_title = $result['title'];
        mysqli_close($dbc);

        return $this->recipe_title;
    }

    //this function returns a single ingredient name
    public function look_up_ingredient_name($ingredient_id)
    {
        $this->ingredient_id = $ingredient_id;

        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        $query = "SELECT ingredient_name
                  FROM ingredient
                  WHERE id = '$this->ingredient_id'";
        $data = mysqli_query($dbc, $query)
            or die('error getting ingredient name');
        $result = mysqli_fetch_array($data);
        $this->ingredient_name = $result['ingredient_name'];
        mysqli_close($dbc);

        return $this->ingredient_name;
    }

    //this function inserts a new row into the recipe table
    public function add_new_recipe($new_recipe_title, $recipe_instruction, $photo)
    {
        $this->new_recipe_title = $new_recipe_title;
        $this->recipe_instruction = $recipe_instruction;
        $this->photo = $photo;

        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');
        $query = "INSERT INTO recipe (title, description, photo)
                  VALUES('$this->new_recipe_title'
                      , '$this->recipe_instruction'
                      , '$this->photo')";
        $data = mysqli_query($dbc, $query)
            or die('error inserting recipe');
        mysqli_close($dbc);

        echo '<div class="alert alert-success" role="alert">'
                . '<p>new recipe successfully added<p></div>';

    }

    //this function inserts a new row into the ingredient table
    public function add_new_ingredient($new_ingredient_name)
    {
        $this->new_ingredient_name = $new_ingredient_name;

        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');
        $query = "INSERT INTO ingredient (ingredient_name)
                  VALUES('$this->new_ingredient_name')";
        $data = mysqli_query($dbc, $query)
            or die('error inserting ingredient item');
        mysqli_close($dbc);

        echo '<div class="alert alert-success" role="alert">'
                . '<p>new item successfully added<p></div>';

    }

    //this function inserts a new row into the recipe_ingredient table
    public function add_new_recipe_ingredient($ri_recipe_id, $ri_ingredient_id, $new_ingredient_description)
    {
        $this->ri_recipe_id = $ri_recipe_id;
        $this->ri_ingredient_id = $ri_ingredient_id;
        $this->new_ingredient_description = $new_ingredient_description;

            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
                or die('error connecting to database');
            $query = "INSERT INTO recipe_ingredient(recipe_id, ingredient_id, ingredient_description)
                      VALUES('$this->ri_recipe_id'
                            , '$this->ri_ingredient_id'
                            , '$this->new_ingredient_description')";
            $data = mysqli_query($dbc, $query)
                or die('error inserting recipe ingredient');
            mysqli_close($dbc);

            echo '<div class="alert alert-success" role="alert">'
                . '<p>new recipe ingredient successfully added<p></div>';

    }

    public function print_all_recipes()
    {

        //connect to database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
            or die('error connecting to database');

        foreach($this->recipe_ids as $recipe_id) {

            //select recipe information
            $query_r = "SELECT title, description, photo
                        FROM recipe
                        WHERE id = '$recipe_id';";
            $data_r = mysqli_query($dbc, $query_r)
                or die('error querying database');
            $row_r = mysqli_fetch_array($data_r);

            //select ingredient information
            $query_i = "SELECT ingredient_description
                        FROM recipe_ingredient
                        WHERE recipe_id = '$recipe_id'";
            $data_i = mysqli_query($dbc, $query_i)
                or die('error querying database');

            //Recipe card
            echo '<div id="recipeCard" class="card">';

            //check for photo before displaying
            if(!empty($row_r['photo']))
            {
                echo '<img class="card-img-top" src="images/' . $row_r['photo']
                . '" alt="photo of ' .  $row_r['title']
                . '">';
            }
            //title
            echo'<h2 class="card-title">' . $row_r['title'] . '</h2>';


            //Ingredient List
            echo '<div class=card-body>';
            echo '<div class="col-6 float-left"> '
                    . '<h3>Ingredients</h3>'
                    . '<ul>';
            while($row_i = mysqli_fetch_array($data_i))
            {
                echo '<li>' . $row_i['ingredient_description'] . '</li>';
            }
            echo '</ul></div><br/>';

            //Recipe directions
            echo '<div class="float-none">'
                    . '<h3>Directions</h3>'
                    . '<div>' . $row_r['description'] . '</div></div>';

            //add to my list button
            echo '<form method="post" action="addtolist.php">'
                    . '<input type="hidden" id="recipeId" name="recipeId"'
                    . 'value="' . $recipe_id . '">'
                    . '<input class="btn btn-light" type="submit" value="Add to my list">'
                . '</form>';

            //ending div for card body
            echo '</div>';
            //ending div for recipe card
            echo '</div>';
        } // end of for each loop
        mysqli_close($dbc);
    }

}
?>

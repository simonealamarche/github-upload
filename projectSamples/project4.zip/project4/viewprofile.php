<?php

    //start the session
    require_once('startsession.php');
    //header
    require_once('header.php');
    //database connection
    require_once('connectvars.php');

    //user list class
    require_once('userlist.php');

    //make sure that user is logged in
    if (!isset($_SESSION['user_id']))
    {
        echo '<p class="alert alert-warning" role="alert">'
                . 'Please <a href="login.php">log in</a>'
                . ' or <a href="signup.php">create an account </a>'
                . 'to start building your shopping list</p>';
        exit();
    }
    else
    {
        $user_id = $_SESSION['user_id'];
    }

?>
    <div class="page-intro">
        <h1>Your Shopping List</h1>
        <p>customize your shopping list</p>
    </div>
<?php

    //create user list
    $ul = new UserList;
    //$my_id_list = $ul->create_my_list_ids($user_id);
    //$my_list = $ul->create_my_list_names($user_id);
    $my_list = $ul->create_assoc_list($user_id);

    // Serialize $my_list and save it to a SESSION var
    $_SESSION['list'] = serialize($my_list);

    //Display list
    echo '<form method="post" action="remove.php">'
            . '<ul>';


    foreach($my_list as $list_id => $list_value)
    {
        /*
        //create list items without spaces preg_replace
        if (Trim($list_item) != '')
        {
            $list_item = preg_replace('/\s/', '_', $list_item);
        }
        */
        //look up list item id to use instead of list_item

        echo '<li>' . $list_value . ' '
            . '<input type="checkbox" id="removeItem" name="' . $list_id. '" '
            . ' value="' . $list_id . '"></li>';
    }
    //button to remove
    echo '</ul>'
        . '<input type="submit" value="Remove">'
        . '</form><br/>';
    //end of list

    //add to shopping list
    echo '<form method="post" action="editlist.php">'
            . '<input type="text" name="enterItem" id="enterItem">'
            . '<input type="submit" value="Add to my list">'
          . '</form>';


    require_once('footer.php');

?>

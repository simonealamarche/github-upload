<?php

    //Header
    require_once('header.php');

    //application variables and database connection
    //require_once('appvars.php');
    require_once('connectvars.php');

    // Connect to the database
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
        or die('Error Connecting to MySQL Server');

    // pass through signup data on submit
    if (isset($_POST['submit']))
    {
        //Grab user entered data
        $username = mysqli_real_escape_string($dbc, trim($_POST['username']));
        $password1 = mysqli_real_escape_string($dbc, trim($_POST['password1']));
        $password2 = mysqli_real_escape_string($dbc, trim($_POST['password2']));
        $hash = password_hash($password1, PASSWORD_DEFAULT);

        if (!empty($username) && !empty($password1) && !empty($password2)
                && ($password1 == $password2)) {

            //verify unique username. Select statement should return 0 rows
            $query = "SELECT * FROM user
                      WHERE username = '$username'";
            $data = mysqli_query($dbc, $query);

            if (mysqli_num_rows($data) == 0)
            {
                //Insert data into the database
                $query = "INSERT INTO user (username, password)
                          VALUES ('$username', '$hash');";
                mysqli_query($dbc, $query)
                    or die('error querying database');


                //success message
                echo '<p>Your new account has been succesfully created<p>';

                mysqli_close($dbc);
                exit();

            }//end of: if username is unique
            else
            {
                // username is not unique so display an error message
                echo '<p class="error">An account already exists for this '
                        . 'username. Please try again.</p>';
                $username = "";
            }//end of else
        }// end of: if fields not empty, passwords match
        else
        {
            echo '<p class="error">You must enter all fields and passwords '
                    . 'must match</p>';

        }//end of else
    } //end of: if submit
    mysqli_close($dbc);
 ?>
<p>Create a new account</p>
<form method="post"
       action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="username">Username:</label>
    <input type="text"
           id="username"
           name="username"
           value="<?php if (!empty($username)) echo $username; ?>" /><br />

    <label for="password1">Password:</label>
    <input type="password"
           id="password1"
           name="password1" /><br />

    <label for="password2">Password (retype):</label>
    <input type="password"
           id="password2"
           name="password2" /><br />

    <input type="submit" value="Sign Up" name="submit" />
</form>
